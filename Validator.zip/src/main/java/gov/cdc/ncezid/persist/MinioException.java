package gov.cdc.ncezid.persist;

public class MinioException extends Exception {
    public MinioException(String message) {
        super(message);
    }
}
