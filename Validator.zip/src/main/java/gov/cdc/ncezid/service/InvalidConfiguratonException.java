package gov.cdc.ncezid.service;

public class InvalidConfiguratonException extends Throwable {
    public InvalidConfiguratonException(String message) {
        super(message);
    }
}
