package gov.cdc.ncezid.model;

import java.util.List;

import lombok.Data;

@Data
public class UnformattedRow {

    private List<String> fields;

}
