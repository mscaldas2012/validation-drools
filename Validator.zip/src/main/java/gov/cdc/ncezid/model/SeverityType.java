package gov.cdc.ncezid.model;

public enum SeverityType {
    UNKNOWN,
    ERROR,
    WARNING
}
