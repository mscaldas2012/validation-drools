package gov.cdc.ncezid.model;

public enum IssueScopeType {
    UNKNOWN,
    FILE,
    METADATA,
    FIELD,
    CROSS_FIELD,
    CROSS_ROW
}