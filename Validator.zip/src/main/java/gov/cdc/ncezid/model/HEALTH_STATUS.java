package gov.cdc.ncezid.model;

public enum HEALTH_STATUS {
    OK, UNHEALTHY, HEALTHY, DOWN
}
